"""
@author: szqs
@time: 2020-12-05
@description: 基于半监督和Boosting结合的改进自训练方法
"""
import numpy as np
from sklearn.ensemble import AdaBoostClassifier


class SSLTraining:
    def __init__(self, base_classifier=AdaBoostClassifier(), max_iterations=50):
        self.base_classifier = base_classifier
        self.max_iterations = max_iterations

    def fit(self, X, y, U):
        y = np.copy(y)

        iteration = 0
        while iteration < self.max_iterations:
            self._fit_iteration(X, y, U)
            iteration += 1

    def _fit_iteration(self, X, y, U):
        threshold = 0.7

        clf = self.base_classifier
        clf.fit(X, y)

        probabilities = clf.predict_proba(U)
        threshold = min(threshold, probabilities.max())
        over_thresh = probabilities.max(axis=1) >= threshold
        labels = clf.predict(U[over_thresh])
        X = np.concatenate((X, U[over_thresh]))
        y = np.concatenate((y, labels))

    def predict(self, X):
        return self.base_classifier.predict(X)
