"""
@author: szqs
@time: 2020-12-05
@description: 普通自训练
"""
import numpy as np
from sklearn.tree import DecisionTreeClassifier


class SelfTraining:
    def __init__(self, base_classifier=DecisionTreeClassifier(), max_iterations=100):
        self.base_classifier = base_classifier
        self.max_iterations = max_iterations

    def fit(self, X, y, U):
        y = np.copy(y)

        iteration = 0
        while iteration < self.max_iterations:
            self._fit_iteration(X, y, U)
            iteration += 1

    def _fit_iteration(self, X, y, U):
        threshold = 0.7

        clf = self.base_classifier
        clf.fit(X, y)

        probabilities = clf.predict_proba(U)
        threshold = min(threshold, probabilities.max())
        over_thresh = probabilities.max(axis=1) >= threshold
        labels = clf.predict(U[over_thresh])
        X = np.concatenate((X, U[over_thresh]))
        y = np.concatenate((y, labels))
        index = [np.argwhere(U == item)[0][0] for item in U[over_thresh]]
        U = np.delete(U, index)

    def predict(self, X):
        return self.base_classifier.predict(X)

