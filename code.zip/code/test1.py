import numpy as np
import pandas as pd
import warnings

warnings.filterwarnings('ignore')

from sklearn.model_selection import train_test_split, cross_val_score, KFold
from sklearn.metrics import balanced_accuracy_score, f1_score, roc_auc_score, accuracy_score
from tri_training import TriTraining
from self_training import SelfTraining
from SSL_training import SSLTraining
# from ssL_Boosting import SSL_Boosting
from sklearn.model_selection import KFold

kf = KFold(n_splits=5, shuffle=True, random_state=0)
from sklearn.utils import shuffle
temp_df = pd.read_csv('data1500.csv')
train, test = train_test_split(temp_df, test_size=0.2,random_state=0)
# temp_df = pd.read_csv('data850.csv')
# train, test = train_test_split(temp_df, test_size=0.2,random_state=0)
np.random.seed(0)
for i in [0.4]:
    train_index = np.random.choice(train.shape[0], int(train.shape[0] * i), replace=False)
    u_index = list(set(np.arange(train.shape[0])) - set(train_index))
    Xtrain, ytrain = np.array(train.iloc[:, :-1])[train_index], np.array(train.iloc[:, -1])[train_index]
    Xtest, ytest = np.array(test.iloc[:, :-1]), np.array(test.iloc[:, -1])
    unlabel = np.array(train.iloc[:, :-1])[u_index]

    clf2 = SelfTraining()
    clf2.fit(Xtrain, ytrain, unlabel)
    pred2 = clf2.predict(Xtest)
    F02 = accuracy_score(ytest, pred2)

    clf3 = TriTraining()
    clf3.fit(Xtrain, ytrain, unlabel)
    pred3 = clf3.predict(Xtest)
    F03 = accuracy_score(ytest, pred3)

    clf4 = SSLTraining()
    clf4.fit(Xtrain, ytrain, unlabel)
    pred4 = clf4.predict(Xtest)
    F04 = accuracy_score(ytest, pred4)

    print('rate : ', i)
    print('self_training : accuracy_score : ', F02)
    print('TriTraining : accuracy_score : ', F03)
    print('SSL_training : accuracy_score : ', F04)
    print('\n')
